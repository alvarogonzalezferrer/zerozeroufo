import { TokenProps } from "./token";
export declare function TokenSelect(props: TokenProps): import("preact").VNode<any> | import("preact").VNode<any>[];
