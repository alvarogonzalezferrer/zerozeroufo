export declare function request(endpoint: string, method?: string, body?: BodyInit | null): Promise<any>;
