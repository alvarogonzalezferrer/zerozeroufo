import { Props } from "../player-app";
export declare function Tips(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
