import { Props } from "../../player-app";
interface LatencyInfoProps extends Props {
    class?: string;
    asButton?: boolean;
}
export declare function LatencyInfo(props: LatencyInfoProps): import("preact").VNode<any> | import("preact").VNode<any>[];
export {};
