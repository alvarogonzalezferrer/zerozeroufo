import { Props } from "../player-app";
interface RegionProps extends Props {
    class?: string;
}
export declare function Region(props: RegionProps): import("preact").VNode<any> | import("preact").VNode<any>[];
export {};
