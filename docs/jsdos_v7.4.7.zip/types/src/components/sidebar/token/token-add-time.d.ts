import { TokenProps } from "./token";
export declare function TokenAddTime(props: TokenProps): import("preact").VNode<any> | import("preact").VNode<any>[];
