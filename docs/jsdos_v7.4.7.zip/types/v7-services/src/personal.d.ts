export declare const uploadsS3Bucket = "doszone-uploads";
export declare function getPersonalBundleKey(namespace: string, id: string, bundleUrl: string, publishToken: string | undefined): string;
export declare function getPersonalBundleUrl(namespace: string, id: string, bundleUrl: string, publishToken: string | undefined): string;
